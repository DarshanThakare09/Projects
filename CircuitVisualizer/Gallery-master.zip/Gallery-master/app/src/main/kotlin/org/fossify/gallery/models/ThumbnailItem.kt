package org.fossify.gallery.models

open class ThumbnailItem
