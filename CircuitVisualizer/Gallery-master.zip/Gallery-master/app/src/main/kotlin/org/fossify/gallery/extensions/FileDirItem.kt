package org.fossify.gallery.extensions

import org.fossify.commons.models.FileDirItem

fun FileDirItem.isDownloadsFolder() = path.isDownloadsFolder()
