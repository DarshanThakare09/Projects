package org.fossify.gallery.helpers

import android.view.View
import androidx.viewpager.widget.ViewPager

class DefaultPageTransformer : ViewPager.PageTransformer {
    override fun transformPage(view: View, position: Float) {}
}
