package org.fossify.gallery.interfaces

interface PlaybackSpeedListener {
    fun updatePlaybackSpeed(speed: Float)
}
