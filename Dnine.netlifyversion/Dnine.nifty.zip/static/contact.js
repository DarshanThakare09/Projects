function showframe1() {
    let conpg1 = document.getElementById("que");

    if (conpg1.style.display == "none") {
        conpg1.style.display = "flex";
    }
    else {
        conpg1.style.display = "none";
    }

    // conpg.style.color = "red";
}
function showframe3() {
    let conpg2 = document.getElementById("touch");

    if (conpg2.style.display == "none") {
        conpg2.style.display = "flex";
    }
    else {
        conpg2.style.display = "none";
    }
    // conpg.style.color = "red";
}
function showframe2() {

    let conpg3 = document.getElementById("con");

    if (conpg3.style.display == "none") {
        conpg3.style.display = "flex";
    }
    else {
        conpg3.style.display = "none";
    }
    // conpg.style.color = "red";
}